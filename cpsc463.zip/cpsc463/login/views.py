from django.shortcuts import render
# from django.http import HttpResponse


# def login(request):
#     return HttpResponse('<h1>Login</h1>')

# def about(request):
#     return HttpResponse('<h1>About</h1>')





posts = [
    {
        'author': 'author 1',
        'title': 'title 1',
        'content': 'content 1',
        'date_posted': 'March 1, 2020'
    },
    {
        'author': 'author 2',
        'title': 'title 2',
        'content': 'content 2',
        'date_posted': 'March 2, 2020'
    }
]

myNum = 123
def login(request):
    # context = {
    #     'posts': posts
    # }
    # context = posts
    

   
    # context = {
    # 'some_string' : "This is some string",
    # 'some_number'   : myNum
    # }



    context = {}

    context ['some_string'] = "This is some string"
    context ['some_number'] = myNum
    context ['myPost'] = posts
    
    myList = []
    myList.append(1)
    myList.append(2)
    myList.append(3)
    myList.append(4)

    context['myList'] = myList
    # return render(request, 'blog/home.html', context)







    return render(request, 'login/login.html', context)

def about(request):
    return render(request, 'login/about.html', {'title': 'About'})